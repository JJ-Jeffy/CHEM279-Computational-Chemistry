// Problem set 3 
// University of California, Berkeley 

// Created by : Jeffy Jeffy 
// date: 10/16/23

// Description: This file contains the main program for this project 

#include "molecule.h"
#include "utils.h"
#include <iostream>

using namespace std;

int main(){
    string filename = "C2H2.txt";
    Molecule mol(filename);
    mol.print_geom_info();
    cout << "Molecule was created" << endl;

    double convergence = 1e-6;
    int maxIterations = 100; 
    mol.runSCF(convergence, maxIterations);

    cout << "The OVRA is" << endl;
    print_field(mol.overlapMatrix_derivative());

    cout << "calculate the X Matrix" << endl;
    cout << mol.solveXMatrix(mol.P_alpha_final, mol.P_beta_final) << endl;

    cout << "calculate the Y Matrix" << endl;
    cout << mol.solveYMatrix(mol.P_alpha_final, mol.P_beta_final) << endl;

    cout << "calculate the G Matrix" << endl;
    print_field(mol.calcGammaDerivativeMatrix());

    cout << "calculate the Gradient Nuclear Repulsion Energy" << endl;
    cout << mol.calcGradientRepulsionEnergy() << endl;

    cout << "calculate the Gradient overall energy" << endl;
    cout << mol.calcFinalGradient() << endl;

    return 0;
}